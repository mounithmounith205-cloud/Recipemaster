import React from 'react';
import { Link } from 'react-router-dom';

const RecipeCard = ({ recipe }) => {
  return (
    <div className="recipe-card">
      <img
        src={recipe.imageUrl || 'https://via.placeholder.com/300x200?text=Recipe'}
        alt={recipe.title}
      />
      <div className="recipe-card-body">
        <h3>{recipe.title}</h3>
        <p className="muted">
          {recipe.category} {recipe.cuisine ? `• ${recipe.cuisine}` : ''}
        </p>
        <p className="muted">{recipe.cookingTime} min • {recipe.servings} servings</p>
        <Link to={`/recipes/${recipe._id}`} className="btn-link">View Recipe</Link>
      </div>
    </div>
  );
};

export default RecipeCard;
