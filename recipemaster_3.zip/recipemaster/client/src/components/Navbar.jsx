import React, { useContext, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const [q, setQ] = useState('');
  const navigate = useNavigate();

  const handleSearch = (e) => {
    e.preventDefault();
    navigate(`/search?q=${encodeURIComponent(q)}`);
  };

  return (
    <nav className="navbar">
      <Link to="/" className="brand">RecipeMaster</Link>

      <form onSubmit={handleSearch} className="nav-search">
        <input
          type="text"
          placeholder="Search recipes or ingredients..."
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
        <button type="submit">Search</button>
      </form>

      <div className="nav-links">
        {user ? (
          <>
            <Link to="/my-recipes">My Recipes</Link>
            <Link to="/favorites">Favorites</Link>
            <Link to="/create">+ New Recipe</Link>
            <span className="nav-user">Hi, {user.name}</span>
            <button className="link-btn" onClick={logout}>Logout</button>
          </>
        ) : (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
