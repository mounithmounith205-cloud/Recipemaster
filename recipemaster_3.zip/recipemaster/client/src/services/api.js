import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: API_URL
});

// Attach JWT token to every request if it exists
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// ---- Auth ----
export const registerUser = (data) => api.post('/auth/register', data);
export const loginUser = (data) => api.post('/auth/login', data);
export const getProfile = () => api.get('/auth/profile');

// ---- Recipes ----
export const getRecipes = (params) => api.get('/recipes', { params });
export const getRecipeById = (id) => api.get(`/recipes/${id}`);
export const createRecipe = (data) => api.post('/recipes', data);
export const updateRecipe = (id, data) => api.put(`/recipes/${id}`, data);
export const deleteRecipe = (id) => api.delete(`/recipes/${id}`);
export const getMyRecipes = () => api.get('/recipes/mine/all');
export const toggleFavorite = (id) => api.post(`/recipes/${id}/favorite`);
export const getFavorites = () => api.get('/recipes/favorites/all');
export const generateShareLink = (id) => api.post(`/recipes/${id}/share`);
export const getSharedRecipe = (token) => api.get(`/recipes/shared/${token}`);
export const getNutritionInfo = (id) => api.get(`/recipes/${id}/nutrition`);

export default api;
