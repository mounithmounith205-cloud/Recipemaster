import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getSharedRecipe } from '../services/api';

const SharedRecipe = () => {
  const { token } = useParams();
  const [recipe, setRecipe] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await getSharedRecipe(token);
        setRecipe(data);
      } catch (err) {
        setError(err.response?.data?.message || 'Shared recipe not found');
      }
    };
    load();
  }, [token]);

  if (error) return <div className="container error">{error}</div>;
  if (!recipe) return <div className="container">Loading...</div>;

  return (
    <div className="container recipe-detail">
      <img
        src={recipe.imageUrl || 'https://via.placeholder.com/700x350?text=Recipe'}
        alt={recipe.title}
        className="detail-image"
      />
      <h1>{recipe.title}</h1>
      <p className="muted">
        Shared by {recipe.owner?.name || 'Unknown'} • {recipe.category}
        {recipe.cuisine ? ` • ${recipe.cuisine}` : ''} • {recipe.cookingTime} min • {recipe.servings} servings
      </p>
      <p>{recipe.description}</p>

      <h2>Ingredients</h2>
      <ul>
        {recipe.ingredients.map((ing, i) => (
          <li key={i}>{ing.quantity} {ing.name}</li>
        ))}
      </ul>

      <h2>Steps</h2>
      <ol>
        {recipe.steps.map((step, i) => (
          <li key={i}>{step}</li>
        ))}
      </ol>
    </div>
  );
};

export default SharedRecipe;
