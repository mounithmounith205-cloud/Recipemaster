import React, { useEffect, useState } from 'react';
import { getFavorites } from '../services/api';
import RecipeCard from '../components/RecipeCard';

const Favorites = () => {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const { data } = await getFavorites();
      setRecipes(data);
      setLoading(false);
    };
    load();
  }, []);

  return (
    <div className="container">
      <h1>My Favorite Recipes</h1>
      {loading && <p>Loading...</p>}
      <div className="recipe-grid">
        {recipes.map((r) => (
          <RecipeCard key={r._id} recipe={r} />
        ))}
      </div>
      {!loading && recipes.length === 0 && <p>No favorites saved yet.</p>}
    </div>
  );
};

export default Favorites;
