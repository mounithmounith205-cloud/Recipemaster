import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { getRecipes } from '../services/api';
import RecipeCard from '../components/RecipeCard';

const SearchResults = () => {
  const [searchParams] = useSearchParams();
  const q = searchParams.get('q') || '';
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      // Search matches title/description/ingredients text index,
      // and also filters directly by ingredient name for pantry-based search
      const { data } = await getRecipes({ search: q, ingredient: q });
      setRecipes(data.recipes);
      setLoading(false);
    };
    load();
  }, [q]);

  return (
    <div className="container">
      <h1>Search Results for "{q}"</h1>
      {loading && <p>Searching...</p>}
      <div className="recipe-grid">
        {recipes.map((r) => (
          <RecipeCard key={r._id} recipe={r} />
        ))}
      </div>
      {!loading && recipes.length === 0 && <p>No recipes matched your search.</p>}
    </div>
  );
};

export default SearchResults;
