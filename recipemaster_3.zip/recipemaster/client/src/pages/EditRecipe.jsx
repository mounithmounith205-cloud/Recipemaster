import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getRecipeById, updateRecipe } from '../services/api';

const EditRecipe = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState(null);
  const [ingredients, setIngredients] = useState([]);
  const [steps, setSteps] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await getRecipeById(id);
        setForm(data);
        setIngredients(data.ingredients);
        setSteps(data.steps);
      } catch (err) {
        setError('Failed to load recipe');
      }
    };
    load();
  }, [id]);

  const updateIngredient = (i, field, value) => {
    const copy = [...ingredients];
    copy[i][field] = value;
    setIngredients(copy);
  };

  const updateStep = (i, value) => {
    const copy = [...steps];
    copy[i] = value;
    setSteps(copy);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const payload = {
        ...form,
        ingredients: ingredients.filter((i) => i.name.trim() !== ''),
        steps: steps.filter((s) => s.trim() !== '')
      };
      await updateRecipe(id, payload);
      navigate(`/recipes/${id}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update recipe');
    }
  };

  if (!form) return <div className="container">{error || 'Loading...'}</div>;

  return (
    <div className="container form-container">
      <h2>Edit Recipe</h2>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit}>
        <label>Title</label>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />

        <label>Description</label>
        <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />

        <label>Image URL</label>
        <input value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} />

        <div className="row">
          <div>
            <label>Category</label>
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              {['Breakfast','Lunch','Dinner','Dessert','Snack','Beverage','Other'].map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div>
            <label>Cuisine</label>
            <input value={form.cuisine} onChange={(e) => setForm({ ...form, cuisine: e.target.value })} />
          </div>
        </div>

        <div className="row">
          <div>
            <label>Cooking Time (minutes)</label>
            <input type="number" value={form.cookingTime} onChange={(e) => setForm({ ...form, cookingTime: e.target.value })} />
          </div>
          <div>
            <label>Servings</label>
            <input type="number" value={form.servings} onChange={(e) => setForm({ ...form, servings: e.target.value })} />
          </div>
        </div>

        <label className="checkbox-label">
          <input type="checkbox" checked={form.isPublic} onChange={(e) => setForm({ ...form, isPublic: e.target.checked })} />
          Public recipe
        </label>

        <h3>Ingredients</h3>
        {ingredients.map((ing, i) => (
          <div className="row" key={i}>
            <input value={ing.name} onChange={(e) => updateIngredient(i, 'name', e.target.value)} />
            <input value={ing.quantity} onChange={(e) => updateIngredient(i, 'quantity', e.target.value)} />
          </div>
        ))}
        <button type="button" onClick={() => setIngredients([...ingredients, { name: '', quantity: '' }])}>+ Add Ingredient</button>

        <h3>Steps</h3>
        {steps.map((s, i) => (
          <div key={i}>
            <textarea value={s} onChange={(e) => updateStep(i, e.target.value)} />
          </div>
        ))}
        <button type="button" onClick={() => setSteps([...steps, ''])}>+ Add Step</button>

        <br /><br />
        <button type="submit" className="btn-primary">Update Recipe</button>
      </form>
    </div>
  );
};

export default EditRecipe;
