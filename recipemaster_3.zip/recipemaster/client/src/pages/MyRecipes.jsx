import React, { useEffect, useState } from 'react';
import { getMyRecipes } from '../services/api';
import RecipeCard from '../components/RecipeCard';
import { Link } from 'react-router-dom';

const MyRecipes = () => {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const { data } = await getMyRecipes();
      setRecipes(data);
      setLoading(false);
    };
    load();
  }, []);

  return (
    <div className="container">
      <h1>My Recipes</h1>
      <Link to="/create"><button className="btn-primary">+ Create New Recipe</button></Link>
      {loading && <p>Loading...</p>}
      <div className="recipe-grid">
        {recipes.map((r) => (
          <RecipeCard key={r._id} recipe={r} />
        ))}
      </div>
      {!loading && recipes.length === 0 && <p>You haven't created any recipes yet.</p>}
    </div>
  );
};

export default MyRecipes;
