import React, { useContext, useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import {
  getRecipeById,
  deleteRecipe,
  toggleFavorite,
  generateShareLink,
  getNutritionInfo
} from '../services/api';

const RecipeDetail = () => {
  const { id } = useParams();
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [recipe, setRecipe] = useState(null);
  const [error, setError] = useState('');
  const [shareUrl, setShareUrl] = useState('');
  const [nutrition, setNutrition] = useState(null);
  const [nutritionError, setNutritionError] = useState('');

  useEffect(() => {
    const load = async () => {
      try {
        const { data } = await getRecipeById(id);
        setRecipe(data);
      } catch (err) {
        setError(err.response?.data?.message || 'Failed to load recipe');
      }
    };
    load();
  }, [id]);

  const handleDelete = async () => {
    if (!window.confirm('Delete this recipe permanently?')) return;
    await deleteRecipe(id);
    navigate('/my-recipes');
  };

  const handleFavorite = async () => {
    await toggleFavorite(id);
  };

  const handleShare = async () => {
    const { data } = await generateShareLink(id);
    setShareUrl(data.shareUrl);
  };

  const handleNutrition = async () => {
    setNutritionError('');
    try {
      const { data } = await getNutritionInfo(id);
      setNutrition(data);
    } catch (err) {
      setNutritionError(err.response?.data?.message || 'Nutrition lookup failed');
    }
  };

  if (error) return <div className="container error">{error}</div>;
  if (!recipe) return <div className="container">Loading...</div>;

  const isOwner = user && recipe.owner && user._id === recipe.owner._id;

  return (
    <div className="container recipe-detail">
      <img
        src={recipe.imageUrl || 'https://via.placeholder.com/700x350?text=Recipe'}
        alt={recipe.title}
        className="detail-image"
      />
      <h1>{recipe.title}</h1>
      <p className="muted">
        By {recipe.owner?.name || 'Unknown'} • {recipe.category}
        {recipe.cuisine ? ` • ${recipe.cuisine}` : ''} • {recipe.cookingTime} min • {recipe.servings} servings
      </p>
      <p>{recipe.description}</p>

      <div className="action-bar">
        {user && (
          <button onClick={handleFavorite}>♥ Save to Favorites</button>
        )}
        {isOwner && (
          <>
            <Link to={`/edit/${recipe._id}`}><button>Edit</button></Link>
            <button onClick={handleDelete} className="danger">Delete</button>
            <button onClick={handleShare}>Get Share Link</button>
          </>
        )}
        <button onClick={handleNutrition}>Fetch Nutrition Info</button>
      </div>

      {shareUrl && (
        <p className="share-box">Share this recipe: <a href={shareUrl}>{shareUrl}</a></p>
      )}

      {nutritionError && <p className="error">{nutritionError}</p>}
      {nutrition && (
        <div className="nutrition-box">
          <h3>Nutrition Info (via Spoonacular API)</h3>
          <pre>{JSON.stringify(nutrition, null, 2)}</pre>
        </div>
      )}

      <h2>Ingredients</h2>
      <ul>
        {recipe.ingredients.map((ing, i) => (
          <li key={i}>{ing.quantity} {ing.name}</li>
        ))}
      </ul>

      <h2>Steps</h2>
      <ol>
        {recipe.steps.map((step, i) => (
          <li key={i}>{step}</li>
        ))}
      </ol>
    </div>
  );
};

export default RecipeDetail;
