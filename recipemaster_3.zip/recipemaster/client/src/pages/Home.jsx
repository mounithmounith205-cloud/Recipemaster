import React, { useEffect, useState } from 'react';
import { getRecipes } from '../services/api';
import RecipeCard from '../components/RecipeCard';

const CATEGORIES = ['', 'Breakfast', 'Lunch', 'Dinner', 'Dessert', 'Snack', 'Beverage', 'Other'];

const Home = () => {
  const [recipes, setRecipes] = useState([]);
  const [category, setCategory] = useState('');
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchRecipes = async () => {
      setLoading(true);
      try {
        const { data } = await getRecipes({ category: category || undefined, page });
        setRecipes(data.recipes);
        setPages(data.pages);
      } catch (err) {
        setError('Failed to load recipes');
      } finally {
        setLoading(false);
      }
    };
    fetchRecipes();
  }, [category, page]);

  return (
    <div className="container">
      <h1>Discover Recipes</h1>

      <div className="filter-bar">
        {CATEGORIES.map((c) => (
          <button
            key={c || 'all'}
            className={category === c ? 'chip active' : 'chip'}
            onClick={() => {
              setCategory(c);
              setPage(1);
            }}
          >
            {c || 'All'}
          </button>
        ))}
      </div>

      {loading && <p>Loading recipes...</p>}
      {error && <p className="error">{error}</p>}

      <div className="recipe-grid">
        {recipes.map((r) => (
          <RecipeCard key={r._id} recipe={r} />
        ))}
      </div>

      {!loading && recipes.length === 0 && <p>No recipes found.</p>}

      <div className="pagination">
        <button disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>Prev</button>
        <span> Page {page} of {pages || 1} </span>
        <button disabled={page >= pages} onClick={() => setPage((p) => p + 1)}>Next</button>
      </div>
    </div>
  );
};

export default Home;
