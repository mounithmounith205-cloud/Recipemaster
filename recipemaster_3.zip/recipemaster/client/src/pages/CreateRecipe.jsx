import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createRecipe } from '../services/api';

const emptyIngredient = { name: '', quantity: '' };

const CreateRecipe = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    title: '',
    description: '',
    category: 'Other',
    cuisine: '',
    cookingTime: '',
    servings: '',
    imageUrl: '',
    isPublic: true
  });
  const [ingredients, setIngredients] = useState([{ ...emptyIngredient }]);
  const [steps, setSteps] = useState(['']);
  const [error, setError] = useState('');

  const updateIngredient = (i, field, value) => {
    const copy = [...ingredients];
    copy[i][field] = value;
    setIngredients(copy);
  };

  const updateStep = (i, value) => {
    const copy = [...steps];
    copy[i] = value;
    setSteps(copy);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const payload = {
        ...form,
        cookingTime: Number(form.cookingTime) || 0,
        servings: Number(form.servings) || 1,
        ingredients: ingredients.filter((i) => i.name.trim() !== ''),
        steps: steps.filter((s) => s.trim() !== '')
      };
      const { data } = await createRecipe(payload);
      navigate(`/recipes/${data._id}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to create recipe');
    }
  };

  return (
    <div className="container form-container">
      <h2>Create a New Recipe</h2>
      {error && <p className="error">{error}</p>}
      <form onSubmit={handleSubmit}>
        <label>Title</label>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />

        <label>Description</label>
        <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />

        <label>Image URL</label>
        <input value={form.imageUrl} onChange={(e) => setForm({ ...form, imageUrl: e.target.value })} placeholder="https://..." />

        <div className="row">
          <div>
            <label>Category</label>
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              {['Breakfast','Lunch','Dinner','Dessert','Snack','Beverage','Other'].map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div>
            <label>Cuisine</label>
            <input value={form.cuisine} onChange={(e) => setForm({ ...form, cuisine: e.target.value })} placeholder="e.g. Indian, Italian" />
          </div>
        </div>

        <div className="row">
          <div>
            <label>Cooking Time (minutes)</label>
            <input type="number" value={form.cookingTime} onChange={(e) => setForm({ ...form, cookingTime: e.target.value })} />
          </div>
          <div>
            <label>Servings</label>
            <input type="number" value={form.servings} onChange={(e) => setForm({ ...form, servings: e.target.value })} />
          </div>
        </div>

        <label className="checkbox-label">
          <input type="checkbox" checked={form.isPublic} onChange={(e) => setForm({ ...form, isPublic: e.target.checked })} />
          Make this recipe public (searchable by others)
        </label>

        <h3>Ingredients</h3>
        {ingredients.map((ing, i) => (
          <div className="row" key={i}>
            <input placeholder="Ingredient name" value={ing.name} onChange={(e) => updateIngredient(i, 'name', e.target.value)} />
            <input placeholder="Quantity (e.g. 2 cups)" value={ing.quantity} onChange={(e) => updateIngredient(i, 'quantity', e.target.value)} />
          </div>
        ))}
        <button type="button" onClick={() => setIngredients([...ingredients, { ...emptyIngredient }])}>+ Add Ingredient</button>

        <h3>Steps</h3>
        {steps.map((s, i) => (
          <div key={i}>
            <textarea placeholder={`Step ${i + 1}`} value={s} onChange={(e) => updateStep(i, e.target.value)} />
          </div>
        ))}
        <button type="button" onClick={() => setSteps([...steps, ''])}>+ Add Step</button>

        <br /><br />
        <button type="submit" className="btn-primary">Save Recipe</button>
      </form>
    </div>
  );
};

export default CreateRecipe;
