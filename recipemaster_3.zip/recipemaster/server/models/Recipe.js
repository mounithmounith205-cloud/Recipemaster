const mongoose = require('mongoose');

const ingredientSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    quantity: { type: String, trim: true, default: '' }
  },
  { _id: false }
);

const recipeSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, 'Title is required'],
      trim: true
    },
    description: {
      type: String,
      trim: true,
      default: ''
    },
    ingredients: {
      type: [ingredientSchema],
      required: true,
      validate: (arr) => arr.length > 0
    },
    steps: {
      type: [String],
      required: true,
      validate: (arr) => arr.length > 0
    },
    category: {
      type: String,
      enum: [
        'Breakfast',
        'Lunch',
        'Dinner',
        'Dessert',
        'Snack',
        'Beverage',
        'Other'
      ],
      default: 'Other'
    },
    cuisine: { type: String, trim: true, default: '' },
    cookingTime: { type: Number, default: 0 }, // in minutes
    servings: { type: Number, default: 1 },
    imageUrl: { type: String, trim: true, default: '' },
    isPublic: { type: Boolean, default: true },
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    shareToken: {
      type: String,
      unique: true,
      sparse: true
    }
  },
  { timestamps: true }
);

// Text index for advanced search across title, description, ingredients
recipeSchema.index({
  title: 'text',
  description: 'text',
  'ingredients.name': 'text',
  cuisine: 'text'
});

module.exports = mongoose.model('Recipe', recipeSchema);
