const express = require('express');
const router = express.Router();
const {
  createRecipe,
  getRecipes,
  getRecipeById,
  updateRecipe,
  deleteRecipe,
  getMyRecipes,
  toggleFavorite,
  getFavorites,
  generateShareLink,
  getSharedRecipe,
  getNutritionInfo
} = require('../controllers/recipeController');
const { protect, optionalAuth } = require('../middleware/auth');

// IMPORTANT: specific routes must come before '/:id' routes
router.get('/mine/all', protect, getMyRecipes);
router.get('/favorites/all', protect, getFavorites);
router.get('/shared/:token', getSharedRecipe);

router.route('/')
  .get(getRecipes)
  .post(protect, createRecipe);

router.get('/:id/nutrition', getNutritionInfo);
router.post('/:id/favorite', protect, toggleFavorite);
router.post('/:id/share', protect, generateShareLink);

router.route('/:id')
  .get(optionalAuth, getRecipeById)
  .put(protect, updateRecipe)
  .delete(protect, deleteRecipe);

module.exports = router;
