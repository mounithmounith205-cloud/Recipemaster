const crypto = require('crypto');
const axios = require('axios');
const Recipe = require('../models/Recipe');
const User = require('../models/User');

// @desc    Create a recipe
// @route   POST /api/recipes
// @access  Private
const createRecipe = async (req, res) => {
  try {
    const {
      title,
      description,
      ingredients,
      steps,
      category,
      cuisine,
      cookingTime,
      servings,
      imageUrl,
      isPublic
    } = req.body;

    const recipe = await Recipe.create({
      title,
      description,
      ingredients,
      steps,
      category,
      cuisine,
      cookingTime,
      servings,
      imageUrl,
      isPublic,
      owner: req.user._id
    });

    res.status(201).json(recipe);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get all public recipes (with search, filter, pagination)
// @route   GET /api/recipes
// @access  Public
const getRecipes = async (req, res) => {
  try {
    const {
      search,
      ingredient,
      category,
      cuisine,
      page = 1,
      limit = 12
    } = req.query;

    const query = { isPublic: true };

    // General keyword search matches title/description/ingredients/cuisine.
    // Note: MongoDB's $text operator cannot be combined inside $or, so we
    // use case-insensitive regex across fields instead - simpler and works
    // well for a search bar of this scale.
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { cuisine: { $regex: search, $options: 'i' } },
        { 'ingredients.name': { $regex: search, $options: 'i' } }
      ];
    } else if (ingredient) {
      query['ingredients.name'] = { $regex: ingredient, $options: 'i' };
    }
    if (category) {
      query.category = category;
    }
    if (cuisine) {
      query.cuisine = { $regex: cuisine, $options: 'i' };
    }

    const skip = (Number(page) - 1) * Number(limit);

    const recipes = await Recipe.find(query)
      .populate('owner', 'name')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit));

    const total = await Recipe.countDocuments(query);

    res.json({
      recipes,
      total,
      page: Number(page),
      pages: Math.ceil(total / Number(limit))
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get single recipe by ID
// @route   GET /api/recipes/:id
// @access  Public (if recipe is public) / Private (if owner)
const getRecipeById = async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id).populate(
      'owner',
      'name'
    );

    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }

    if (
      !recipe.isPublic &&
      (!req.user || recipe.owner._id.toString() !== req.user._id.toString())
    ) {
      return res.status(403).json({ message: 'This recipe is private' });
    }

    res.json(recipe);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Update a recipe (owner only)
// @route   PUT /api/recipes/:id
// @access  Private
const updateRecipe = async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    if (recipe.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to edit this recipe' });
    }

    Object.assign(recipe, req.body);
    const updated = await recipe.save();
    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Delete a recipe (owner only)
// @route   DELETE /api/recipes/:id
// @access  Private
const deleteRecipe = async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    if (recipe.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to delete this recipe' });
    }
    await recipe.deleteOne();
    res.json({ message: 'Recipe removed' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get logged-in user's own recipes
// @route   GET /api/recipes/mine/all
// @access  Private
const getMyRecipes = async (req, res) => {
  try {
    const recipes = await Recipe.find({ owner: req.user._id }).sort({
      createdAt: -1
    });
    res.json(recipes);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Toggle favorite/save a recipe
// @route   POST /api/recipes/:id/favorite
// @access  Private
const toggleFavorite = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);
    const recipeId = req.params.id;

    const isFavorited = user.favorites.some(
      (fav) => fav.toString() === recipeId
    );

    if (isFavorited) {
      user.favorites = user.favorites.filter(
        (fav) => fav.toString() !== recipeId
      );
    } else {
      user.favorites.push(recipeId);
    }

    await user.save();
    res.json({ favorites: user.favorites });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Get logged-in user's favorite recipes
// @route   GET /api/recipes/favorites/all
// @access  Private
const getFavorites = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate({
      path: 'favorites',
      populate: { path: 'owner', select: 'name' }
    });
    res.json(user.favorites);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Generate a shareable link/token for a recipe
// @route   POST /api/recipes/:id/share
// @access  Private
const generateShareLink = async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }
    if (recipe.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    if (!recipe.shareToken) {
      recipe.shareToken = crypto.randomBytes(8).toString('hex');
      await recipe.save();
    }

    res.json({
      shareToken: recipe.shareToken,
      shareUrl: `${process.env.CLIENT_URL}/shared/${recipe.shareToken}`
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    View a recipe via its share token (no auth needed)
// @route   GET /api/recipes/shared/:token
// @access  Public
const getSharedRecipe = async (req, res) => {
  try {
    const recipe = await Recipe.findOne({
      shareToken: req.params.token
    }).populate('owner', 'name');
    if (!recipe) {
      return res.status(404).json({ message: 'Shared recipe not found' });
    }
    res.json(recipe);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// @desc    Third-party API integration - fetch nutrition info for a recipe's
//          ingredients using the Spoonacular API
// @route   GET /api/recipes/:id/nutrition
// @access  Public
const getNutritionInfo = async (req, res) => {
  try {
    const recipe = await Recipe.findById(req.params.id);
    if (!recipe) {
      return res.status(404).json({ message: 'Recipe not found' });
    }

    if (!process.env.SPOONACULAR_API_KEY) {
      return res.status(400).json({
        message:
          'SPOONACULAR_API_KEY is not configured on the server (.env file)'
      });
    }

    const ingredientList = recipe.ingredients
      .map((i) => `${i.quantity} ${i.name}`)
      .join('\n');

    const response = await axios.post(
      'https://api.spoonacular.com/recipes/parseIngredients',
      new URLSearchParams({
        ingredientList,
        servings: recipe.servings || 1,
        includeNutrition: true
      }),
      {
        params: { apiKey: process.env.SPOONACULAR_API_KEY },
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
      }
    );

    res.json(response.data);
  } catch (error) {
    res
      .status(500)
      .json({ message: 'Failed to fetch nutrition data', error: error.message });
  }
};

module.exports = {
  createRecipe,
  getRecipes,
  getRecipeById,
  updateRecipe,
  deleteRecipe,
  getMyRecipes,
  toggleFavorite,
  getFavorites,
  generateShareLink,
  getSharedRecipe,
  getNutritionInfo
};
