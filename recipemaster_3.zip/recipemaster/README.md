# RecipeMaster

A full-stack MERN application (MongoDB, Express, React, Node.js) for creating,
searching, organizing, and sharing recipes.

## Folder structure

```
recipemaster/
├── server/          # Node.js + Express + MongoDB backend (REST API)
│   ├── config/db.js
│   ├── controllers/
│   ├── middleware/
│   ├── models/
│   ├── routes/
│   ├── .env.example
│   ├── package.json
│   └── server.js
└── client/          # React frontend
    ├── public/
    ├── src/
    │   ├── components/
    │   ├── context/
    │   ├── pages/
    │   ├── services/api.js
    │   ├── App.js
    │   └── index.js
    ├── .env.example
    └── package.json
```

## Features implemented

- **Auth**: register/login with JWT, password hashing (bcrypt)
- **Create / Read / Update / Delete recipes** (full CRUD, owner-only edit/delete)
- **Advanced search**: by keyword, ingredient ("what's in my pantry"), category, cuisine
- **Organize**: categories, "My Recipes", "Favorites"
- **Share**: generate a public share link (token-based) for any recipe
- **Third-party API integration**: nutrition lookup per recipe via the Spoonacular API
- **REST API** built with Express, tested with Postman
- **MongoDB Atlas** as the cloud database via Mongoose

---

## STEP 1 — Prerequisites

Install on your machine:
1. **Node.js** (v18+) and npm → https://nodejs.org
2. **Git** → https://git-scm.com
3. **Visual Studio Code** → https://code.visualstudio.com
4. **Postman** (for testing the API) → https://www.postman.com/downloads
5. A free **MongoDB Atlas** account → https://www.mongodb.com/cloud/atlas/register

---

## STEP 2 — Set up MongoDB Atlas (cloud database)

1. Sign in to MongoDB Atlas and click **"Build a Database"**.
2. Choose the **free M0 tier**, pick a cloud provider/region close to you, and click **Create**.
3. **Create a database user**: Under *Database Access*, click *Add New Database User*.
   - Choose "Password" authentication.
   - Set a username and password (save these — you'll need them for the connection string).
   - Give it "Read and write to any database" role.
4. **Allow network access**: Under *Network Access*, click *Add IP Address*.
   - For local development, click **"Allow Access from Anywhere"** (0.0.0.0/0), or add your current IP.
5. **Get your connection string**: Go to *Database* → click **Connect** on your cluster →
   *Drivers* → copy the connection string. It looks like:
   ```
   mongodb+srv://<username>:<password>@cluster0.xxxxx.mongodb.net/?retryWrites=true&w=majority
   ```
6. Replace `<username>` and `<password>` with the database user you created, and add your
   database name after `.net/`, e.g.:
   ```
   mongodb+srv://recipeAdmin:MyPassword123@cluster0.xxxxx.mongodb.net/recipemaster?retryWrites=true&w=majority
   ```
   This will be your `MONGO_URI`. You do NOT need to manually create collections —
   Mongoose creates the `users` and `recipes` collections automatically the first
   time you register a user / create a recipe.

---

## STEP 3 — Backend (server) setup

1. Open a terminal in the `server/` folder:
   ```bash
   cd recipemaster/server
   npm install
   ```
2. Create your real environment file:
   ```bash
   cp .env.example .env
   ```
   (On Windows: `copy .env.example .env`)
3. Open `.env` in VS Code and fill in:
   ```
   MONGO_URI=mongodb+srv://recipeAdmin:MyPassword123@cluster0.xxxxx.mongodb.net/recipemaster?retryWrites=true&w=majority
   PORT=5000
   JWT_SECRET=any_long_random_string_here
   SPOONACULAR_API_KEY=your_key_or_leave_blank
   CLIENT_URL=http://localhost:3000
   ```
   - `JWT_SECRET` can be any random string (used to sign login tokens).
   - `SPOONACULAR_API_KEY` is optional — only needed for the "Fetch Nutrition Info"
     button. Get a free key at https://spoonacular.com/food-api (5,000 free
     requests/day). The rest of the app works fine without it.
4. Start the server:
   ```bash
   npm run dev
   ```
   (`npm run dev` uses nodemon for auto-restart; `npm start` runs it plainly.)
5. You should see:
   ```
   MongoDB Atlas connected: cluster0-shard-...
   Server running on port 5000
   ```
6. Test it's alive by visiting **http://localhost:5000** in your browser —
   you should see `{"message":"RecipeMaster API is running"}`.

---

## STEP 4 — Test the API with Postman

Import these requests into Postman (or create them manually):

| Method | URL                                              | Body (JSON)                                         | Auth |
|--------|---------------------------------------------------|-------------------------------------------------------|------|
| POST   | `http://localhost:5000/api/auth/register`         | `{ "name": "Test", "email": "t@test.com", "password": "123456" }` | none |
| POST   | `http://localhost:5000/api/auth/login`             | `{ "email": "t@test.com", "password": "123456" }` | none |
| GET    | `http://localhost:5000/api/recipes`                | —                                                      | none |
| POST   | `http://localhost:5000/api/recipes`                | see sample below                                       | Bearer token |
| GET    | `http://localhost:5000/api/recipes/mine/all`       | —                                                      | Bearer token |
| GET    | `http://localhost:5000/api/recipes?search=chicken` | —                                                      | none |

Sample body for creating a recipe (POST /api/recipes), with header
`Authorization: Bearer <token from login/register response>`:
```json
{
  "title": "Simple Pancakes",
  "description": "Fluffy breakfast pancakes",
  "ingredients": [
    { "name": "flour", "quantity": "2 cups" },
    { "name": "milk", "quantity": "1.5 cups" },
    { "name": "egg", "quantity": "2" }
  ],
  "steps": ["Mix dry ingredients", "Whisk in milk and eggs", "Cook on a griddle"],
  "category": "Breakfast",
  "cuisine": "American",
  "cookingTime": 20,
  "servings": 4,
  "isPublic": true
}
```
Copy the `token` field from the register/login response and paste it into
Postman's **Authorization → Bearer Token** tab for any protected route.

---

## STEP 5 — Frontend (client) setup

1. Open a **new** terminal in the `client/` folder:
   ```bash
   cd recipemaster/client
   npm install
   ```
2. Create your environment file:
   ```bash
   cp .env.example .env
   ```
   It should contain:
   ```
   REACT_APP_API_URL=http://localhost:5000/api
   ```
3. Start the React app:
   ```bash
   npm start
   ```
4. Your browser will open **http://localhost:3000** automatically with the
   RecipeMaster UI. Register an account, create a recipe, search, favorite,
   and generate a share link — all through the UI.

> Keep both terminals running at the same time: one for `server` (port 5000)
> and one for `client` (port 3000).

---

## STEP 6 — Put it on Git / GitHub

From the root `recipemaster/` folder:
```bash
git init
git add .
git commit -m "Initial commit: RecipeMaster MERN app"
```
Create a new empty repository on GitHub (no README/gitignore), then:
```bash
git remote add origin https://github.com/<your-username>/recipemaster.git
git branch -M main
git push -u origin main
```
Both `server/.gitignore` and `client/.gitignore` already exclude `node_modules/`
and `.env` files, so your database credentials and secrets are never pushed.

---

## How data flows into MongoDB Atlas

You never manually add data in Atlas for this app — it's created automatically:
- Registering a user (via the UI or `POST /api/auth/register`) creates a
  document in the `users` collection.
- Creating a recipe (via the UI or `POST /api/recipes`) creates a document in
  the `recipes` collection, linked to the logged-in user via `owner`.
- You can view/inspect this data anytime in Atlas: **Database → Browse Collections**.

If you ever want to seed sample data directly, you can also use **Atlas →
Browse Collections → Insert Document** to manually add a JSON document to the
`recipes` collection, matching the schema in `server/models/Recipe.js`.

---

## Troubleshooting

- **"MongoDB connection error"** → double check `MONGO_URI` in `server/.env`,
  and that your IP is allowed under Atlas Network Access.
- **CORS errors in browser console** → make sure `CLIENT_URL` in `server/.env`
  matches the URL your React app runs on (`http://localhost:3000`).
- **401 Unauthorized** on protected routes → make sure you're logged in and
  the token is stored (check `localStorage` in browser dev tools).
- **Port already in use** → change `PORT` in `server/.env`, or stop the other
  process using that port.
